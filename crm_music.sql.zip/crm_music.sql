-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Mar 10, 2017 at 01:29 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crm_music`
--
CREATE DATABASE IF NOT EXISTS `crm_music` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `crm_music`;

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` bigint(20) unsigned NOT NULL,
  `family_name` varchar(255) DEFAULT NULL,
  `street_address` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `notes` text,
  `billing_history` text,
  `outstanding_balance` int(11) DEFAULT NULL,
  `parent_one_name` varchar(255) DEFAULT NULL,
  `parent_two_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `family_name`, `street_address`, `phone_number`, `email_address`, `notes`, `billing_history`, `outstanding_balance`, `parent_one_name`, `parent_two_name`) VALUES
(1, 'kjh', 'kljh', 'lkjh', 'kljh', 'First entry', 'First entry', 0, 'kjh', 'kjh'),
(2, 'Jay', '', '', '', 'First entry', 'First entry', 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `accounts_courses`
--

CREATE TABLE `accounts_courses` (
  `id` bigint(20) unsigned NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `accounts_images`
--

CREATE TABLE `accounts_images` (
  `id` bigint(20) unsigned NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `image_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `accounts_lessons`
--

CREATE TABLE `accounts_lessons` (
  `id` bigint(20) unsigned NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `lesson_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `accounts_schools`
--

CREATE TABLE `accounts_schools` (
  `id` bigint(20) unsigned NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts_schools`
--

INSERT INTO `accounts_schools` (`id`, `account_id`, `school_id`, `date_of_join`) VALUES
(1, 0, 10, NULL),
(2, 0, 10, NULL),
(3, 0, 10, NULL),
(4, 0, 10, NULL),
(5, 0, 10, NULL),
(6, 0, 10, NULL),
(7, 0, 10, NULL),
(8, 0, 10, NULL),
(9, 0, 10, NULL),
(10, 0, 10, NULL),
(11, 0, 10, NULL),
(12, 0, 10, NULL),
(13, 0, 10, NULL),
(14, 0, 10, NULL),
(15, 0, 10, NULL),
(16, 0, 10, NULL),
(17, 0, 10, NULL),
(18, 0, 10, NULL),
(19, 1, 1, NULL),
(20, 2, 1, NULL),
(21, 3, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `accounts_services`
--

CREATE TABLE `accounts_services` (
  `id` bigint(20) unsigned NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `accounts_students`
--

CREATE TABLE `accounts_students` (
  `id` bigint(20) unsigned NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts_students`
--

INSERT INTO `accounts_students` (`id`, `account_id`, `student_id`, `date_of_join`) VALUES
(1, 1, 15, NULL),
(2, 1, 16, NULL),
(3, 1, 17, NULL),
(4, 2, 18, NULL),
(5, 2, 19, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `accounts_teachers`
--

CREATE TABLE `accounts_teachers` (
  `id` bigint(20) unsigned NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `title` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`title`, `id`) VALUES
('Hungarian Maple Cello  ', 1),
('Bavarian Drum Manufacturing 101', 2),
('Spiritual Inner Voice Development ( room 9 )', 3),
('Hot Wooden-Cactus Drum', 4),
('Tree Branch Foot Flute', 5);

-- --------------------------------------------------------

--
-- Table structure for table `courses_images`
--

CREATE TABLE `courses_images` (
  `id` bigint(20) unsigned NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `image_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `courses_lessons`
--

CREATE TABLE `courses_lessons` (
  `id` bigint(20) unsigned NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `lesson_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses_lessons`
--

INSERT INTO `courses_lessons` (`id`, `course_id`, `lesson_id`, `date_of_join`) VALUES
(1, 4, 2, NULL),
(2, 1, 3, NULL),
(3, 1, 4, NULL),
(4, 5, 5, NULL),
(5, 1, 6, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `courses_schools`
--

CREATE TABLE `courses_schools` (
  `id` bigint(20) unsigned NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses_schools`
--

INSERT INTO `courses_schools` (`id`, `course_id`, `school_id`, `date_of_join`) VALUES
(1, 1, 1, NULL),
(2, 2, 1, NULL),
(3, 3, 1, NULL),
(4, 4, 1, NULL),
(5, 5, 1, NULL),
(6, 6, 7, NULL),
(7, 7, 8, NULL),
(8, 8, 8, NULL),
(9, 9, 8, NULL),
(10, 10, 14, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `courses_services`
--

CREATE TABLE `courses_services` (
  `id` bigint(20) unsigned NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `courses_students`
--

CREATE TABLE `courses_students` (
  `id` bigint(20) unsigned NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses_students`
--

INSERT INTO `courses_students` (`id`, `course_id`, `student_id`, `date_of_join`) VALUES
(37, 2, 14, '2017-03-09 11:31:20'),
(38, 4, 14, '2017-03-09 11:31:22'),
(39, 4, 14, '2017-03-09 11:31:25'),
(40, 2, 14, '2017-03-09 11:31:27'),
(41, 1, 14, '2017-03-09 11:31:30'),
(42, 1, 14, '2017-03-09 11:31:31'),
(43, 1, 14, '2017-03-09 11:34:04'),
(44, 1, 14, '2017-03-09 11:34:27'),
(45, 1, 14, '2017-03-09 11:34:49'),
(46, 1, 14, '2017-03-09 11:35:11'),
(47, 1, 14, '2017-03-09 11:35:26'),
(48, 1, 14, '2017-03-09 11:36:01'),
(49, 1, 14, '2017-03-09 11:36:26'),
(50, 1, 14, '2017-03-09 11:37:01'),
(51, 1, 14, '2017-03-09 11:37:43'),
(52, 2, 14, '2017-03-09 01:07:13'),
(53, 1, 14, '2017-03-09 01:31:29'),
(54, 1, 15, '2017-03-09 01:32:19'),
(55, 5, 14, '2017-03-09 02:16:56'),
(56, 5, 14, '2017-03-09 02:17:48'),
(57, 5, 14, '2017-03-09 02:18:10'),
(58, 5, 14, '2017-03-09 02:18:22'),
(59, 5, 14, '2017-03-09 02:18:48'),
(60, 2, 14, '2017-03-09 02:46:43'),
(61, 2, 14, '2017-03-09 02:46:43'),
(62, 2, 14, '2017-03-09 02:46:44'),
(63, 2, 14, '2017-03-09 02:46:44'),
(64, 2, 14, '2017-03-09 02:46:44'),
(65, 2, 14, '2017-03-09 02:46:44'),
(66, 2, 14, '2017-03-09 02:46:44'),
(67, 2, 14, '2017-03-09 02:46:44'),
(68, 4, 21, '2017-03-09 03:22:54'),
(69, 3, 21, '2017-03-09 03:54:02');

-- --------------------------------------------------------

--
-- Table structure for table `courses_teachers`
--

CREATE TABLE `courses_teachers` (
  `id` bigint(20) unsigned NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `idpic` int(10) unsigned NOT NULL,
  `caption` varchar(45) NOT NULL,
  `img` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `images_lessons`
--

CREATE TABLE `images_lessons` (
  `id` bigint(20) unsigned NOT NULL,
  `image_id` int(11) DEFAULT NULL,
  `lesson_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `images_schools`
--

CREATE TABLE `images_schools` (
  `id` bigint(20) unsigned NOT NULL,
  `image_id` int(11) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `images_services`
--

CREATE TABLE `images_services` (
  `id` bigint(20) unsigned NOT NULL,
  `image_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `images_students`
--

CREATE TABLE `images_students` (
  `id` bigint(20) unsigned NOT NULL,
  `image_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `images_teachers`
--

CREATE TABLE `images_teachers` (
  `id` bigint(20) unsigned NOT NULL,
  `image_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

CREATE TABLE `lessons` (
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `content` text,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`title`, `description`, `content`, `id`) VALUES
('Learn How to Fluoridiam Flute', 'Captivate your mind with transcendent wooden laughter!', 'Open up the spiritual gates of your inner lost child, find him/her inside the locked doors. ', 3),
('Fundamentals of Space', 'Question everything, except for the maple leaf...', 'True identity arises and subsides in cosmic space time events', 4),
('Farkloin 101', 'Find the marriage of sounds and carpet', '', 6);

-- --------------------------------------------------------

--
-- Table structure for table `lessons_schools`
--

CREATE TABLE `lessons_schools` (
  `id` bigint(20) unsigned NOT NULL,
  `lesson_id` int(11) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lessons_schools`
--

INSERT INTO `lessons_schools` (`id`, `lesson_id`, `school_id`, `date_of_join`) VALUES
(1, 1, 1, NULL),
(2, 2, 1, NULL),
(3, 3, 1, NULL),
(4, 4, 1, NULL),
(5, 5, 1, NULL),
(6, 6, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `lessons_services`
--

CREATE TABLE `lessons_services` (
  `id` bigint(20) unsigned NOT NULL,
  `lesson_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lessons_students`
--

CREATE TABLE `lessons_students` (
  `id` bigint(20) unsigned NOT NULL,
  `lesson_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lessons_teachers`
--

CREATE TABLE `lessons_teachers` (
  `id` bigint(20) unsigned NOT NULL,
  `lesson_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `id` bigint(20) unsigned NOT NULL,
  `school_name` varchar(255) DEFAULT NULL,
  `manager_name` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `business_address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`id`, `school_name`, `manager_name`, `phone_number`, `email`, `business_address`, `city`, `state`, `country`, `zip`, `type`) VALUES
(1, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(2, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(3, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(4, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(5, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(6, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(7, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(8, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(9, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(10, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(11, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(12, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(13, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(14, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(15, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(16, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(17, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music'),
(18, 'SPMS', 'Carlos Munoz Kampff', '617-780-8362', 'info@starpowermusic.net', 'PO 6267', 'Alameda', 'CA', 'USA', '94706', 'music');

-- --------------------------------------------------------

--
-- Table structure for table `schools_services`
--

CREATE TABLE `schools_services` (
  `id` bigint(20) unsigned NOT NULL,
  `school_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `schools_students`
--

CREATE TABLE `schools_students` (
  `id` bigint(20) unsigned NOT NULL,
  `school_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schools_students`
--

INSERT INTO `schools_students` (`id`, `school_id`, `student_id`, `date_of_join`) VALUES
(1, 8, 4, NULL),
(2, 10, 5, NULL),
(3, 15, 6, NULL),
(4, 15, 7, NULL),
(5, 15, 8, NULL),
(6, 1, 9, NULL),
(7, 1, 10, NULL),
(8, 1, 11, NULL),
(9, 1, 12, NULL),
(10, 1, 13, NULL),
(11, 1, 14, NULL),
(12, 1, 15, NULL),
(13, 1, 16, NULL),
(14, 1, 17, NULL),
(15, 1, 18, NULL),
(16, 1, 19, NULL),
(17, 1, 20, NULL),
(18, 1, 21, NULL),
(19, 1, 22, NULL),
(20, 1, 23, NULL),
(21, 1, 24, NULL),
(22, 1, 25, NULL),
(23, 1, 26, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `schools_teachers`
--

CREATE TABLE `schools_teachers` (
  `id` bigint(20) unsigned NOT NULL,
  `school_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schools_teachers`
--

INSERT INTO `schools_teachers` (`id`, `school_id`, `teacher_id`, `date_of_join`) VALUES
(1, 1, 1, NULL),
(2, 1, 2, NULL),
(3, 1, 3, NULL),
(4, 1, 4, NULL),
(5, 5, 5, NULL),
(6, 8, 6, NULL),
(7, 8, 7, NULL),
(8, 8, 8, NULL),
(9, 13, 10, NULL),
(10, 14, 11, NULL),
(11, 16, 12, NULL),
(12, 18, 13, NULL),
(13, 15, 14, NULL),
(14, 1, 15, NULL),
(15, 1, 16, NULL),
(16, 1, 17, NULL),
(17, 1, 18, NULL),
(18, 1, 19, NULL),
(19, 1, 20, NULL),
(20, 1, 21, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `description` varchar(255) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT NULL,
  `paid_for` int(1) DEFAULT NULL,
  `notes` text,
  `date_of_service` datetime DEFAULT NULL,
  `recurrence` varchar(255) DEFAULT NULL,
  `attendance` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `services_students`
--

CREATE TABLE `services_students` (
  `id` bigint(20) unsigned NOT NULL,
  `service_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `services_teachers`
--

CREATE TABLE `services_teachers` (
  `id` bigint(20) unsigned NOT NULL,
  `service_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` bigint(20) unsigned NOT NULL,
  `student_name` varchar(255) DEFAULT NULL,
  `notes` text
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_name`, `notes`) VALUES
(21, 'Martinstein Jaknordoff', 'Thursday 9th of March 2017 02:52:00 PM of first entry.'),
(22, 'Jane Doelercran', 'Thursday 9th of March 2017 02:52:15 PM of first entry.'),
(23, 'Playontoes Taleroid', 'Thursday 9th of March 2017 02:55:31 PM of first entry.'),
(24, 'Sarah Dinklewaud', 'Thursday 9th of March 2017 03:01:05 PM of first entry.'),
(25, 'Helgon Terontister', 'Thursday 9th of March 2017 03:35:50 PM of first entry.'),
(26, 'Geraldo Dunderhoff', 'Thursday 9th of March 2017 03:36:06 PM of first entry.');

-- --------------------------------------------------------

--
-- Table structure for table `students_teachers`
--

CREATE TABLE `students_teachers` (
  `id` bigint(20) unsigned NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `date_of_join` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students_teachers`
--

INSERT INTO `students_teachers` (`id`, `student_id`, `teacher_id`, `date_of_join`) VALUES
(15, 20, 21, NULL),
(16, 20, 21, NULL),
(17, 20, 21, NULL),
(18, 21, 16, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` bigint(20) unsigned NOT NULL,
  `teacher_name` varchar(255) DEFAULT NULL,
  `instrument` varchar(100) DEFAULT NULL,
  `notes` text
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `teacher_name`, `instrument`, `notes`) VALUES
(16, 'Jedidiah Watercrest', 'Back-wood Tail Deerhorn', 'Thursday 9th of March 2017 02:49:26 PM of first entry.'),
(17, 'Gunther Maildates', 'Crested Forrest Horn', 'Thursday 9th of March 2017 02:50:02 PM of first entry.'),
(18, 'Kaliktra Jundiker', 'Kale Chime Drum', 'Thursday 9th of March 2017 02:50:42 PM of first entry.'),
(19, 'Sadiacre Hamtrosterman', 'Moon Water Flute', 'Thursday 9th of March 2017 02:51:26 PM of first entry.'),
(20, 'Dart Fabertork', 'Yellow Harp Ladle', 'Thursday 9th of March 2017 02:56:04 PM of first entry.'),
(21, 'Zohar Madlrimer', 'German Bag Throser', 'Thursday 9th of March 2017 02:59:07 PM of first entry.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `accounts_courses`
--
ALTER TABLE `accounts_courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `accounts_images`
--
ALTER TABLE `accounts_images`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `accounts_lessons`
--
ALTER TABLE `accounts_lessons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `accounts_schools`
--
ALTER TABLE `accounts_schools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `accounts_services`
--
ALTER TABLE `accounts_services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `accounts_students`
--
ALTER TABLE `accounts_students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `accounts_teachers`
--
ALTER TABLE `accounts_teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `courses_images`
--
ALTER TABLE `courses_images`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `courses_lessons`
--
ALTER TABLE `courses_lessons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `courses_schools`
--
ALTER TABLE `courses_schools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `courses_services`
--
ALTER TABLE `courses_services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `courses_students`
--
ALTER TABLE `courses_students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `courses_teachers`
--
ALTER TABLE `courses_teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`idpic`);

--
-- Indexes for table `images_lessons`
--
ALTER TABLE `images_lessons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `images_schools`
--
ALTER TABLE `images_schools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `images_services`
--
ALTER TABLE `images_services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `images_students`
--
ALTER TABLE `images_students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `images_teachers`
--
ALTER TABLE `images_teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `lessons`
--
ALTER TABLE `lessons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `lessons_schools`
--
ALTER TABLE `lessons_schools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `lessons_services`
--
ALTER TABLE `lessons_services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `lessons_students`
--
ALTER TABLE `lessons_students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `lessons_teachers`
--
ALTER TABLE `lessons_teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `schools_services`
--
ALTER TABLE `schools_services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `schools_students`
--
ALTER TABLE `schools_students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `schools_teachers`
--
ALTER TABLE `schools_teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `services_students`
--
ALTER TABLE `services_students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `services_teachers`
--
ALTER TABLE `services_teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `students_teachers`
--
ALTER TABLE `students_teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `accounts_courses`
--
ALTER TABLE `accounts_courses`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `accounts_images`
--
ALTER TABLE `accounts_images`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `accounts_lessons`
--
ALTER TABLE `accounts_lessons`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `accounts_schools`
--
ALTER TABLE `accounts_schools`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `accounts_services`
--
ALTER TABLE `accounts_services`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `accounts_students`
--
ALTER TABLE `accounts_students`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `accounts_teachers`
--
ALTER TABLE `accounts_teachers`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `courses_images`
--
ALTER TABLE `courses_images`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `courses_lessons`
--
ALTER TABLE `courses_lessons`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `courses_schools`
--
ALTER TABLE `courses_schools`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `courses_services`
--
ALTER TABLE `courses_services`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `courses_students`
--
ALTER TABLE `courses_students`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT for table `courses_teachers`
--
ALTER TABLE `courses_teachers`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `idpic` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `images_lessons`
--
ALTER TABLE `images_lessons`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `images_schools`
--
ALTER TABLE `images_schools`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `images_services`
--
ALTER TABLE `images_services`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `images_students`
--
ALTER TABLE `images_students`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `images_teachers`
--
ALTER TABLE `images_teachers`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `lessons`
--
ALTER TABLE `lessons`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `lessons_schools`
--
ALTER TABLE `lessons_schools`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `lessons_services`
--
ALTER TABLE `lessons_services`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `lessons_students`
--
ALTER TABLE `lessons_students`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `lessons_teachers`
--
ALTER TABLE `lessons_teachers`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `schools_services`
--
ALTER TABLE `schools_services`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `schools_students`
--
ALTER TABLE `schools_students`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `schools_teachers`
--
ALTER TABLE `schools_teachers`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `services_students`
--
ALTER TABLE `services_students`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `services_teachers`
--
ALTER TABLE `services_teachers`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `students_teachers`
--
ALTER TABLE `students_teachers`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
